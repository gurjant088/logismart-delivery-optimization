Place the dataset workbook here, e.g.:
  Competitor Beta Dataset for Students.xlsx

Expected sheets: "Delivery Orders", "Vehicle Master", "Zone Distance Matrix".
The dataset file itself is not committed to this repository (see .gitignore) —
add your own copy locally.
