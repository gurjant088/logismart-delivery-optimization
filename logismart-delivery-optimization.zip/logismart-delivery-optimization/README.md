# LogiSmart Delivery Route & Resource Optimization System

A prototype optimization engine for delivery route planning and vehicle
resource allocation, built for a Master's-level (MSDS) minor project.

The client scenario (**LogiSmart India**) is fictional; the delivery-order
and vehicle datasets used here represent a realistic, anonymised industry
scenario.

## What it does

1. **Loads and validates** delivery order, vehicle fleet and zone-distance
   data (8 automated data-quality checks).
2. **Allocates** orders to vehicles with a priority-ordered, capacity- and
   time-aware bin-packing heuristic, modelled as a multi-trip dispatch
   backlog (vehicles can run several trips across the review period).
3. **Routes** each trip's stops with a nearest-neighbour heuristic against
   a zone-to-zone distance matrix.
4. **Compares** baseline vs optimized KPIs: total distance, estimated cost,
   average delay, on-time rate, order-allocation rate and vehicle
   utilisation.

## Results on the reference dataset (1,800 orders, 52 vehicles)

| KPI | Baseline | Optimized | Improvement |
|---|---|---|---|
| Total Distance | 77,599 km | 30,715.7 km | **60.4%** |
| Estimated Cost | ₹789,636 | ₹307,157 | **61.1%** |
| Average Delay | 8.76 min | 0.11 min | **98.7%** |
| On-Time Rate | 67.89% | 97.44% | **43.5%** (relative) |
| Order Allocation Rate | n/a | 100% | — |
| Avg Vehicle Utilisation | n/a | 90.0% | — |
| Vehicle-Trips (dispatches) | n/a | 538 | — |
| Distinct Vehicles Used | n/a | 47 of 52 | 5 correctly excluded (Maintenance) |

## Project structure

```
logismart-delivery-optimization/
├── src/
│   └── optimizer.py      # Core engine: load, validate, allocate, route, compute KPIs
├── tests/
│   └── test_optimizer.py # 8 functional/edge-case tests (pytest)
├── docs/                  # Architecture notes / diagrams (optional)
├── requirements.txt
└── README.md
```

## Setup

```bash
git clone https://github.com/<your-username>/logismart-delivery-optimization.git
cd logismart-delivery-optimization
pip install -r requirements.txt
```

Place your dataset file (an `.xlsx` workbook with `Delivery Orders`,
`Vehicle Master` and `Zone Distance Matrix` sheets) somewhere accessible —
by default the test suite looks in `data/`, but you can point anywhere.

## Usage

Run the full pipeline from the command line:

```bash
python src/optimizer.py "data/Competitor Beta Dataset for Students.xlsx" results/
```

This prints the validation report and the baseline-vs-optimized KPI table,
and writes `routes_output.csv`, `orders_with_optimized_delay.csv`,
`kpi_summary.json` and `unallocated.json` to the given output directory.

Or use it as a library:

```python
from src.optimizer import load_data, build_trips, optimize_routes, compute_kpis

orders_df, vehicles_df, dist_df = load_data("data/dataset.xlsx")
trips, unallocated = build_trips(orders_df, vehicles_df)
routes_df = optimize_routes(trips, dist_df)
kpis, orders_with_delay = compute_kpis(orders_df, vehicles_df, routes_df, trips, unallocated)
```

## Testing

```bash
DATASET_PATH="data/Competitor Beta Dataset for Students.xlsx" pytest tests/ -v
```

Covers: capacity-constraint enforcement, exclusion of vehicles under
maintenance, overweight-order detection, missing-field detection,
no-feasible-route handling, duplicate-ID detection, full-dataset
allocation coverage, and the full data-validation checklist.

## Design notes & assumptions

- **Multi-trip dispatch model:** the dataset has no date/timestamp field
  and order volume (1,800) far exceeds what the fleet (52 vehicles) could
  complete in a single shift, so orders are allocated as a backlog across
  multiple sequential trips per vehicle rather than one order set per
  vehicle per day.
- **Allocation heuristic:** first-fit-decreasing bin packing, grouped by
  (hub, required vehicle type), processed in priority order (High → Medium
  → Low), respecting both weight capacity and a working-minutes budget
  derived from the dataset's own average speed.
- **Routing heuristic:** nearest-neighbour per trip. Chosen over an exact
  TSP solver because each trip carries a small number of stops, making the
  optimality gap negligible relative to the O(k!) cost of an exact
  solution at any meaningful scale.

## Limitations & future work

- No live traffic or GPS integration — uses a static zone distance matrix.
- Nearest-neighbour routing is not guaranteed globally optimal per trip.
- Static, pre-dispatch planner — does not support dynamic re-optimization
  for orders arriving after the plan is generated.

Future enhancements could include a formal VRP solver (e.g. OR-Tools),
live traffic data, and rolling/dynamic re-optimization.

## License

MIT — see [LICENSE](LICENSE).
