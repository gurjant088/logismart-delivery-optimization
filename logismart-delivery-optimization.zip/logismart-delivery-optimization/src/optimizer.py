# -*- coding: utf-8 -*-
"""
LogiSmart India - Smart Delivery Route and Resource Optimization System
=========================================================================

A prototype optimization engine that:
  1. Loads and validates delivery order, vehicle fleet and zone-distance data
  2. Allocates orders to vehicles using a priority-ordered, capacity- and
     time-aware bin-packing heuristic (multi-trip dispatch model)
  3. Sequences each trip's stops with a nearest-neighbour routing heuristic
  4. Computes baseline vs optimized KPIs (distance, cost, delay, on-time
     rate, allocation rate, utilisation)

Usage (CLI):
    python src/optimizer.py path/to/dataset.xlsx [output_dir]

Usage (as a library):
    from optimizer import load_data, validate, build_trips, optimize_routes, compute_kpis

    orders_df, vehicles_df, dist_df = load_data("dataset.xlsx")
    checks = validate(orders_df, vehicles_df)
    trips, unallocated = build_trips(orders_df, vehicles_df)
    routes_df = optimize_routes(trips, dist_df)
    kpis, orders_with_delay = compute_kpis(orders_df, vehicles_df, routes_df, trips, unallocated)
"""

import argparse
import json
import os
import sys
from collections import defaultdict

import pandas as pd

pd.set_option('display.width', 120)

TYPE_RANK = {"Bike": 0, "Van": 1, "Mini Truck": 2}
PRIORITY_RANK = {"High": 0, "Medium": 1, "Low": 2}


# =============================================================================
# STEP 1 - DATA LOADING
# =============================================================================
def load_data(path):
    """Load the Delivery Orders, Vehicle Master and Zone Distance Matrix sheets."""
    orders_df = pd.read_excel(path, sheet_name="Delivery Orders")
    vehicles_df = pd.read_excel(path, sheet_name="Vehicle Master")
    dist_df = pd.read_excel(path, sheet_name="Zone Distance Matrix", index_col=0)
    return orders_df, vehicles_df, dist_df


# =============================================================================
# STEP 2 - VALIDATION
# =============================================================================
def validate(orders_df, vehicles_df):
    """Run data-quality checks. Returns a list of (check_name, issue_count) tuples."""
    checks = [
        ("Duplicate Order_ID", int(orders_df['Order_ID'].duplicated().sum())),
        ("Missing values in Delivery Orders", int(orders_df.isna().sum().sum())),
        ("Missing values in Vehicle Master", int(vehicles_df.isna().sum().sum())),
        ("Non-positive Distance_Km", int((orders_df['Distance_Km'] <= 0).sum())),
        ("Non-positive Package_Weight_Kg", int((orders_df['Package_Weight_Kg'] <= 0).sum())),
        ("Package weight exceeding largest vehicle capacity",
         int((orders_df['Package_Weight_Kg'] > vehicles_df['Capacity_Kg'].max()).sum())),
        ("Orders referencing an Origin_Hub with zero vehicles",
         int((~orders_df['Origin_Hub'].isin(vehicles_df['Hub'].unique())).sum())),
        ("Vehicles with unavailable capacity <= 0", int((vehicles_df['Capacity_Kg'] <= 0).sum())),
    ]
    return checks


# =============================================================================
# STEP 3 - DATA STRUCTURES
# =============================================================================
def build_fleet_by_hub(vehicles_df):
    fleet_by_hub = defaultdict(list)
    for _, v in vehicles_df.iterrows():
        fleet_by_hub[v['Hub']].append({
            "Vehicle_ID": v['Vehicle_ID'], "Hub": v['Hub'], "Vehicle_Type": v['Vehicle_Type'],
            "Type_Rank": TYPE_RANK[v['Vehicle_Type']], "Capacity_Kg": v['Capacity_Kg'],
            "Cost_per_Km_INR": v['Cost_per_Km_INR'], "Max_Working_Minutes": v['Max_Working_Minutes'],
            "Available": v['Availability'] == "Available",
        })
    return fleet_by_hub


def build_graph(dist_df):
    return {i: {j: dist_df.loc[i, j] for j in dist_df.columns} for i in dist_df.index}


def avg_speed_kmph(orders_df):
    travel_min = orders_df['Existing_Estimated_Time_Min'] - orders_df['Service_Time_Min']
    return float(orders_df['Existing_Planned_Distance_Km'].sum() / (travel_min.sum() / 60.0))


# =============================================================================
# STEP 4 - ALLOCATION (multi-trip bin-packing, priority ordered)
# ASSUMPTION: order volume exceeds the fleet's single-shift capacity, so this
# is modelled as a multi-trip dispatch backlog rather than one trip/vehicle.
# =============================================================================
def build_trips(orders_df, vehicles_df):
    fleet_by_hub = build_fleet_by_hub(vehicles_df)
    speed = avg_speed_kmph(orders_df)

    trips, unallocated = [], []
    orders_sorted = orders_df.copy()
    orders_sorted['_prio_rank'] = orders_sorted['Priority'].map(PRIORITY_RANK)
    orders_sorted = orders_sorted.sort_values(by=['_prio_rank', 'Package_Weight_Kg'], ascending=[True, False])

    groups = defaultdict(list)
    for _, order in orders_sorted.iterrows():
        hub, req_type = order['Origin_Hub'], order['Required_Vehicle_Type']
        if req_type not in TYPE_RANK or not fleet_by_hub[hub]:
            unallocated.append({"Order_ID": order['Order_ID'], "Reason": "No fleet at Origin_Hub"})
            continue
        groups[(hub, req_type)].append(order)

    for (hub, vtype), group_orders in groups.items():
        vehicles_of_type = [v for v in fleet_by_hub[hub] if v['Vehicle_Type'] == vtype and v['Available']]
        if not vehicles_of_type:
            for order in group_orders:
                unallocated.append({"Order_ID": order['Order_ID'], "Reason": f"No available {vtype} at {hub}"})
            continue
        capacity = vehicles_of_type[0]['Capacity_Kg']
        max_minutes = vehicles_of_type[0]['Max_Working_Minutes']

        bins = []
        for order in group_orders:
            weight = order['Package_Weight_Kg']
            need_minutes = order['Service_Time_Min'] + (order['Distance_Km'] / speed) * 60.0

            placed = False
            for b in bins:
                if b['weight'] + weight <= capacity and b['minutes'] + need_minutes <= max_minutes:
                    b['weight'] += weight
                    b['minutes'] += need_minutes
                    b['orders'].append(order)
                    placed = True
                    break
            if not placed:
                if weight > capacity or need_minutes > max_minutes:
                    unallocated.append({"Order_ID": order['Order_ID'],
                                         "Reason": "Exceeds single-vehicle capacity or working-minute budget"})
                else:
                    bins.append({'weight': weight, 'minutes': need_minutes, 'orders': [order]})

        for i, b in enumerate(bins):
            vehicle = vehicles_of_type[i % len(vehicles_of_type)]
            trips.append({"Vehicle_ID": vehicle['Vehicle_ID'], "Hub": hub, "Vehicle_Type": vtype,
                           "Capacity_Kg": capacity, "Cost_per_Km_INR": vehicle['Cost_per_Km_INR'],
                           "Trip_No": i + 1, "Orders": b['orders']})
    return trips, unallocated


# =============================================================================
# STEP 5 - ROUTE OPTIMIZATION (nearest-neighbour per trip)
# =============================================================================
def nearest_neighbour_route(graph, hub, stops):
    if not stops:
        return 0.0
    remaining, current, total = list(stops), hub, 0.0
    while remaining:
        nxt = min(remaining, key=lambda z: graph[current][z])
        total += graph[current][nxt]
        current = nxt
        remaining.remove(nxt)
    return total


def optimize_routes(trips, dist_df):
    graph = build_graph(dist_df)
    records = []
    for t in trips:
        stops = [o['Destination_Zone'] for o in t['Orders']]
        route_km = nearest_neighbour_route(graph, t['Hub'], stops)
        load = sum(o['Package_Weight_Kg'] for o in t['Orders'])
        records.append({
            "Trip_ID": f"{t['Vehicle_ID']}-T{t['Trip_No']}", "Vehicle_ID": t['Vehicle_ID'], "Hub": t['Hub'],
            "Vehicle_Type": t['Vehicle_Type'], "Stops": len(stops), "Route_Km": round(route_km, 2),
            "Load_Kg": round(load, 2), "Capacity_Kg": t['Capacity_Kg'],
            "Utilisation_%": round(100 * load / t['Capacity_Kg'], 1),
            "Estimated_Cost_INR": round(route_km * t['Cost_per_Km_INR'], 2),
        })
    return pd.DataFrame(records)


# =============================================================================
# STEP 6 - KPI COMPARISON
# =============================================================================
def _pct_improve(base, opt, lower_is_better=True):
    if base == 0:
        return 0.0
    return (base - opt) / base if lower_is_better else (opt - base) / base


def compute_kpis(orders_df, vehicles_df, routes_df, trips, unallocated):
    baseline_total_distance = orders_df['Existing_Planned_Distance_Km'].sum()
    baseline_avg_delay = orders_df['Delay_Min'].mean()
    baseline_on_time_rate = (orders_df['Delivery_Status'] == 'On Time').mean()

    rank_cost = vehicles_df.assign(rank=vehicles_df['Vehicle_Type'].map(TYPE_RANK)) \
        .groupby('rank')['Cost_per_Km_INR'].first().reset_index()
    tmp = orders_df.assign(rank=orders_df['Required_Vehicle_Type'].map(TYPE_RANK)).merge(rank_cost, on='rank')
    baseline_total_cost = float((tmp['Existing_Planned_Distance_Km'] * tmp['Cost_per_Km_INR']).sum())

    optimized_total_distance = routes_df['Route_Km'].sum()
    optimized_total_cost = routes_df['Estimated_Cost_INR'].sum()
    allocation_rate = 1 - (len(unallocated) / len(orders_df))
    avg_vehicle_utilisation = routes_df['Utilisation_%'].mean()

    speed = avg_speed_kmph(orders_df)
    order_to_trip = {o['Order_ID']: f"{t['Vehicle_ID']}-T{t['Trip_No']}" for t in trips for o in t['Orders']}
    trip_route_km = dict(zip(routes_df['Trip_ID'], routes_df['Route_Km']))
    trip_stop_count = dict(zip(routes_df['Trip_ID'], routes_df['Stops']))

    def optimized_delay(row):
        trip_id = order_to_trip.get(row['Order_ID'])
        if trip_id is None:
            return row['Delay_Min']
        share_km = trip_route_km[trip_id] / trip_stop_count[trip_id]
        optimized_travel_min = (share_km / speed) * 60.0
        existing_travel_min = row['Existing_Estimated_Time_Min'] - row['Service_Time_Min']
        time_saved = max(0.0, existing_travel_min - optimized_travel_min)
        return max(0.0, row['Delay_Min'] - time_saved)

    orders_df = orders_df.copy()
    orders_df['Optimized_Delay_Min'] = orders_df.apply(optimized_delay, axis=1)
    optimized_avg_delay = orders_df['Optimized_Delay_Min'].mean()
    optimized_on_time_rate = (orders_df['Optimized_Delay_Min'] <= 0).mean()

    return {
        "Total Distance (km)": (round(baseline_total_distance, 1), round(optimized_total_distance, 1),
                                 _pct_improve(baseline_total_distance, optimized_total_distance)),
        "Estimated Cost (INR)": (round(baseline_total_cost, 0), round(optimized_total_cost, 0),
                                  _pct_improve(baseline_total_cost, optimized_total_cost)),
        "Average Delay (min)": (round(baseline_avg_delay, 2), round(optimized_avg_delay, 2),
                                 _pct_improve(baseline_avg_delay, optimized_avg_delay)),
        "On-Time Rate": (round(baseline_on_time_rate, 4), round(optimized_on_time_rate, 4),
                          _pct_improve(baseline_on_time_rate, optimized_on_time_rate, lower_is_better=False)),
        "Order Allocation Rate": (None, round(allocation_rate, 4), None),
        "Avg Vehicle Utilisation (%)": (None, round(avg_vehicle_utilisation, 1), None),
        "Vehicle-Trips (dispatches)": (None, int(routes_df.shape[0]), None),
        "Distinct Vehicles Used": (None, int(routes_df['Vehicle_ID'].nunique()), None),
        "Vehicles Available": (None, int(vehicles_df.shape[0]), None),
    }, orders_df


# =============================================================================
# CLI ENTRY POINT
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="LogiSmart delivery route & resource optimizer")
    parser.add_argument("data_path", help="Path to the dataset .xlsx file")
    parser.add_argument("output_dir", nargs="?", default=".", help="Directory to write result files to")
    args = parser.parse_args()

    if not os.path.isfile(args.data_path):
        sys.exit(f"File not found: {args.data_path}")
    os.makedirs(args.output_dir, exist_ok=True)

    print(f"[OK] Loading data from: {args.data_path}")
    orders_df, vehicles_df, dist_df = load_data(args.data_path)
    print(f"[OK] Loaded {len(orders_df)} orders, {len(vehicles_df)} vehicles, "
          f"{dist_df.shape[0]}x{dist_df.shape[1]} distance matrix.\n")

    print("=== VALIDATION ===")
    for name, val in validate(orders_df, vehicles_df):
        print(f"  {name}: {val}")

    trips, unallocated = build_trips(orders_df, vehicles_df)
    routes_df = optimize_routes(trips, dist_df)
    kpis, orders_with_delay = compute_kpis(orders_df, vehicles_df, routes_df, trips, unallocated)

    print("\n=== BASELINE vs OPTIMIZED KPIs ===")
    for k, (b, o, imp) in kpis.items():
        imp_str = f"{imp*100:.1f}%" if imp is not None else "n/a"
        print(f"  {k}: baseline={b}, optimized={o}, improvement={imp_str}")
    print(f"\n  Unallocated orders: {len(unallocated)}")

    routes_df.to_csv(os.path.join(args.output_dir, "routes_output.csv"), index=False)
    orders_with_delay.to_csv(os.path.join(args.output_dir, "orders_with_optimized_delay.csv"), index=False)
    with open(os.path.join(args.output_dir, "kpi_summary.json"), "w") as f:
        json.dump({k: list(v) for k, v in kpis.items()}, f, indent=2, default=str)
    with open(os.path.join(args.output_dir, "unallocated.json"), "w") as f:
        json.dump(unallocated, f, indent=2, default=str)

    print(f"\n[OK] Result files written to: {args.output_dir}")


if __name__ == "__main__":
    main()
