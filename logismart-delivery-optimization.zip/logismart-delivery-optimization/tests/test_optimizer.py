# -*- coding: utf-8 -*-
"""
Functional test suite for the LogiSmart optimization engine.

Run with:
    pytest tests/test_optimizer.py -v

Requires the dataset file; set its path via the DATASET_PATH environment
variable, or edit DEFAULT_DATASET_PATH below.
"""

import os
import sys

import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from optimizer import load_data, validate, build_trips, optimize_routes  # noqa: E402

DEFAULT_DATASET_PATH = "data/Competitor Beta Dataset for Students.xlsx"
DATASET_PATH = os.environ.get("DATASET_PATH", DEFAULT_DATASET_PATH)

pytestmark = pytest.mark.skipif(
    not os.path.isfile(DATASET_PATH),
    reason=f"Dataset not found at '{DATASET_PATH}'. Set DATASET_PATH env var to its location.",
)


@pytest.fixture(scope="module")
def data():
    orders_df, vehicles_df, dist_df = load_data(DATASET_PATH)
    trips, unallocated = build_trips(orders_df, vehicles_df)
    routes_df = optimize_routes(trips, dist_df)
    return {
        "orders_df": orders_df, "vehicles_df": vehicles_df, "dist_df": dist_df,
        "trips": trips, "unallocated": unallocated, "routes_df": routes_df,
    }


def test_tc01_capacity_constraint_respected(data):
    """TC-01: No trip's load should exceed its assigned vehicle's capacity."""
    over_capacity = data["routes_df"][data["routes_df"]["Load_Kg"] > data["routes_df"]["Capacity_Kg"] + 1e-6]
    assert len(over_capacity) == 0


def test_tc02_maintenance_vehicles_excluded(data):
    """TC-02: Vehicles flagged 'Maintenance' must never appear in a trip."""
    maint_ids = set(data["vehicles_df"].loc[data["vehicles_df"]["Availability"] == "Maintenance", "Vehicle_ID"])
    used_ids = set(data["routes_df"]["Vehicle_ID"])
    assert maint_ids.isdisjoint(used_ids)


def test_tc03_overweight_order_flagged(data):
    """TC-03: A 550kg order should exceed the fleet's largest capacity (500kg)."""
    max_capacity = data["vehicles_df"]["Capacity_Kg"].max()
    assert 550.0 > max_capacity


def test_tc04_missing_field_detected():
    """TC-04: A validator should catch a null Distance_Km value."""
    orders_df, vehicles_df, _ = load_data(DATASET_PATH)
    bad_df = orders_df.copy()
    bad_df.loc[0, "Distance_Km"] = None
    assert int(bad_df["Distance_Km"].isna().sum()) == 1


def test_tc05_no_fleet_hub_has_no_vehicles(data):
    """TC-05: A fictional hub with no fleet should not appear in Vehicle Master."""
    assert "Central Hub" not in data["vehicles_df"]["Hub"].unique()


def test_tc06_duplicate_order_id_detected(data):
    """TC-06: Duplicating one row should be caught by the duplicate-ID check."""
    dup_df = pd.concat([data["orders_df"], data["orders_df"].iloc[[0]]], ignore_index=True)
    assert int(dup_df["Order_ID"].duplicated().sum()) == 1


def test_tc07_full_dataset_allocation_coverage(data):
    """TC-07: All real orders should be allocated (0 unallocated)."""
    assert len(data["unallocated"]) == 0


def test_validation_checks_pass_on_clean_data(data):
    """The eight data-quality checks should all report 0 issues on the supplied dataset."""
    checks = validate(data["orders_df"], data["vehicles_df"])
    for name, count in checks:
        assert count == 0, f"Validation check failed: {name} = {count}"
